﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-C4K4IG2\SQLEXPRESS01;Initial Catalog=master;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (con.State== ConnectionState.Open)
        {
            con.Close();
        }
        con.Open();

        if(!IsPostBack)
        {
            GridView1.Visible = false;
            addi.Visible = false;
            Div1.Visible = false;
        }

       
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        addi.Visible = false;
        Div1.Visible = false;
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from TestTable";
        cmd.ExecuteNonQuery();
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
        GridView1.Visible = true;
    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        Div1.Visible = false;
        GridView1.Visible = false;
        addi.Visible = true;
        
    }

    protected void inset(object sender, EventArgs e)
    {
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into TestTable values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')";
        cmd.ExecuteNonQuery();

        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
    }


    protected void Button4_Click(object sender, EventArgs e)
    {
        GridView1.Visible = false;
        addi.Visible = false;
        Div1.Visible = true;
    }

    protected void upd(object sender, EventArgs e)
    {
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "update TestTable set FNAME='" + TextBox4.Text + "',City='" + TextBox5.Text + "',Salary='" +Convert.ToInt64(TextBox6.Text) + "' where FNAME ='"+TextBox7.Text+"'";
        cmd.ExecuteNonQuery();

        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
    }
}